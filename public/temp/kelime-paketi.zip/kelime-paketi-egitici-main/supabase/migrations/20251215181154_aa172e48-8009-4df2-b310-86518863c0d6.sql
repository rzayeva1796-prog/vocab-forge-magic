-- Create table for dialog content (question-answer pairs)
CREATE TABLE public.word_dialogs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  package_name text NOT NULL,
  english text NOT NULL,
  question text NOT NULL,
  answer text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(package_name, english)
);

-- Enable RLS
ALTER TABLE public.word_dialogs ENABLE ROW LEVEL SECURITY;

-- Public access policy
CREATE POLICY "Public access to word_dialogs" 
ON public.word_dialogs 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Create table for rejected dialogs
CREATE TABLE public.rejected_dialogs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  package_name text NOT NULL,
  english text NOT NULL,
  question text NOT NULL,
  answer text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.rejected_dialogs ENABLE ROW LEVEL SECURITY;

-- Public access policy
CREATE POLICY "Public access to rejected_dialogs" 
ON public.rejected_dialogs 
FOR ALL 
USING (true)
WITH CHECK (true);
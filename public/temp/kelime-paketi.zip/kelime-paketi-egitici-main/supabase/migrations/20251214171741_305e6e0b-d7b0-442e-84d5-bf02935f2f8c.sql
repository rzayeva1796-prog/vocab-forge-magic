-- Cümleler için tablo oluştur
CREATE TABLE public.word_sentences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  word_id UUID NOT NULL REFERENCES public.words(id) ON DELETE CASCADE,
  sentence TEXT NOT NULL,
  sentence_turkish TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Reddedilen cümleler için tablo (çöp kutusu)
CREATE TABLE public.rejected_sentences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  word_id UUID NOT NULL REFERENCES public.words(id) ON DELETE CASCADE,
  sentence TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- RLS aktifleştir
ALTER TABLE public.word_sentences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rejected_sentences ENABLE ROW LEVEL SECURITY;

-- Public erişim politikaları
CREATE POLICY "Public access to word_sentences" 
ON public.word_sentences 
FOR ALL 
USING (true) 
WITH CHECK (true);

CREATE POLICY "Public access to rejected_sentences" 
ON public.rejected_sentences 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Unique constraint - her kelime için tek cümle
ALTER TABLE public.word_sentences ADD CONSTRAINT unique_word_sentence UNIQUE (word_id);
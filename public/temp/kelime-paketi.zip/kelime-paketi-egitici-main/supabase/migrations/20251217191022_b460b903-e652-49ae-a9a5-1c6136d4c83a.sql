-- Create table for conversation catalog stories
CREATE TABLE public.conversation_stories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  package_name TEXT NOT NULL,
  story TEXT NOT NULL,
  transcription TEXT,
  accuracy INTEGER,
  incorrect_words JSONB DEFAULT '[]'::jsonb,
  word_practice_results JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.conversation_stories ENABLE ROW LEVEL SECURITY;

-- Public access policy
CREATE POLICY "Public access to conversation_stories"
ON public.conversation_stories
FOR ALL
USING (true)
WITH CHECK (true);
-- Word packages table
CREATE TABLE public.word_packages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Words table
CREATE TABLE public.words (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id UUID NOT NULL REFERENCES public.word_packages(id) ON DELETE CASCADE,
  english TEXT NOT NULL,
  turkish TEXT NOT NULL,
  image_url TEXT,
  word_index INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Game content table (stores AI-generated sentences and questions)
CREATE TABLE public.game_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  word_id UUID NOT NULL REFERENCES public.words(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL, -- 'sentence', 'question'
  content TEXT NOT NULL,
  options JSONB, -- for questions: [{text: "...", isCorrect: boolean}]
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User progress table
CREATE TABLE public.user_progress (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id UUID NOT NULL REFERENCES public.word_packages(id) ON DELETE CASCADE,
  round_index INTEGER NOT NULL DEFAULT 0, -- 0-9 for 10 rounds
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.word_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.words ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;

-- Public read/write policies (no auth required for this app)
CREATE POLICY "Public access to word_packages" ON public.word_packages FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public access to words" ON public.words FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public access to game_content" ON public.game_content FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public access to user_progress" ON public.user_progress FOR ALL USING (true) WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_words_package ON public.words(package_id);
CREATE INDEX idx_game_content_word ON public.game_content(word_id);
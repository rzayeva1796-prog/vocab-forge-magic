-- Add rejected_images column to track deleted/rejected image URLs
ALTER TABLE public.words 
ADD COLUMN IF NOT EXISTS rejected_images TEXT[] DEFAULT '{}';

-- Add comment for documentation
COMMENT ON COLUMN public.words.rejected_images IS 'Array of rejected/deleted image URLs to avoid re-fetching';
-- Create storage bucket for cached books
INSERT INTO storage.buckets (id, name, public) 
VALUES ('cached-books', 'cached-books', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public read access to cached books
CREATE POLICY "Public read access for cached books"
ON storage.objects FOR SELECT
USING (bucket_id = 'cached-books');

-- Allow public insert for cached books (since no auth)
CREATE POLICY "Public insert access for cached books"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'cached-books');

-- Create table to track cached books
CREATE TABLE public.book_cache (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  external_book_id TEXT NOT NULL UNIQUE,
  original_url TEXT NOT NULL,
  cached_path TEXT NOT NULL,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.book_cache ENABLE ROW LEVEL SECURITY;

-- Public access policy
CREATE POLICY "Public access to book_cache"
ON public.book_cache
FOR ALL
USING (true)
WITH CHECK (true);
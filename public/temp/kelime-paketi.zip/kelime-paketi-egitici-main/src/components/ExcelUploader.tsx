import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, FileSpreadsheet, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ExcelUploaderProps {
  onUploadComplete: (packageId: string) => void;
}

export function ExcelUploader({ onUploadComplete }: ExcelUploaderProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setProgress('Excel dosyası okunuyor...');

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json<{ A: string; B: string }>(worksheet, { header: ['A', 'B'] });

      // Skip header row if present
      const words = jsonData
        .slice(1)
        .filter(row => row.A && row.B)
        .slice(0, 50)
        .map((row, index) => ({
          english: String(row.A).trim(),
          turkish: String(row.B).trim(),
          word_index: index
        }));

      if (words.length < 50) {
        toast({
          title: 'Yetersiz kelime',
          description: `Excel dosyasında sadece ${words.length} kelime bulundu. 50 kelime gerekli.`,
          variant: 'destructive'
        });
        setIsLoading(false);
        return;
      }

      setProgress('Kelime paketi oluşturuluyor...');

      // Create word package
      const { data: packageData, error: packageError } = await supabase
        .from('word_packages')
        .insert({ name: file.name.replace('.xlsx', '').replace('.xls', '') })
        .select()
        .single();

      if (packageError) throw packageError;

      setProgress('Kelimeler kaydediliyor...');

      // Insert words
      const wordsToInsert = words.map(w => ({
        package_id: packageData.id,
        english: w.english,
        turkish: w.turkish,
        word_index: w.word_index
      }));

      const { data: insertedWords, error: wordsError } = await supabase
        .from('words')
        .insert(wordsToInsert)
        .select();

      if (wordsError) throw wordsError;

      // Generate AI content for each round (5 words per round)
      for (let round = 0; round < 10; round++) {
        setProgress(`AI içerik oluşturuluyor... (Tur ${round + 1}/10)`);
        
        const roundWords = insertedWords.slice(round * 5, (round + 1) * 5);
        
        // Generate sentences
        try {
          const sentenceResponse = await supabase.functions.invoke('generate-content', {
            body: { 
              words: roundWords.map(w => ({ english: w.english, turkish: w.turkish })),
              type: 'sentences'
            }
          });

          if (sentenceResponse.data?.content) {
            const sentences = sentenceResponse.data.content;
            for (const sentence of sentences) {
              const word = roundWords.find(w => w.english.toLowerCase() === sentence.word?.toLowerCase());
              if (word) {
                await supabase.from('game_content').insert({
                  word_id: word.id,
                  content_type: 'sentence',
                  content: sentence.sentence
                });
              }
            }
          }
        } catch (e) {
          console.error('Error generating sentences:', e);
        }

        // Generate questions
        try {
          const questionResponse = await supabase.functions.invoke('generate-content', {
            body: { 
              words: roundWords.map(w => ({ english: w.english, turkish: w.turkish })),
              type: 'questions'
            }
          });

          if (questionResponse.data?.content) {
            const questions = questionResponse.data.content;
            for (const q of questions) {
              const word = roundWords.find(w => w.english.toLowerCase() === q.word?.toLowerCase());
              if (word) {
                await supabase.from('game_content').insert({
                  word_id: word.id,
                  content_type: 'question',
                  content: q.question,
                  options: [{ text: q.wrongAnswer, isCorrect: false }]
                });
              }
            }
          }
        } catch (e) {
          console.error('Error generating questions:', e);
        }
      }

      toast({
        title: 'Başarılı!',
        description: '50 kelime başarıyla yüklendi ve oyun içeriği oluşturuldu.'
      });

      onUploadComplete(packageData.id);
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: 'Hata',
        description: 'Dosya yüklenirken bir hata oluştu.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
      setProgress('');
    }
  };

  return (
    <div className="flex flex-col items-center p-6">
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileSelect}
        className="hidden"
      />

      <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-4">
        <FileSpreadsheet className="w-10 h-10 text-primary" />
      </div>

      <h3 className="text-lg font-semibold text-foreground mb-2">Excel Dosyası Yükle</h3>
      <p className="text-sm text-muted-foreground text-center mb-6">
        A sütununda İngilizce, B sütununda Türkçe kelimeler olmalı.<br />
        En az 50 kelime gerekli.
      </p>

      {isLoading ? (
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">{progress}</p>
        </div>
      ) : (
        <Button
          onClick={() => fileInputRef.current?.click()}
          className="w-full max-w-xs"
        >
          <Upload className="w-4 h-4 mr-2" />
          Dosya Seç
        </Button>
      )}
    </div>
  );
}

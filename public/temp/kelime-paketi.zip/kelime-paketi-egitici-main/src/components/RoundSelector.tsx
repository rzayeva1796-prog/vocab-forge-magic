import { Check, Lock, Play } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface RoundSelectorProps {
  completedRounds: number[];
  totalWords: number;
  onSelectRound: (round: number) => void;
  onBack: () => void;
}

export function RoundSelector({ completedRounds, totalWords, onSelectRound, onBack }: RoundSelectorProps) {
  // Calculate rounds based on total words
  const wordsPerRound = 5;
  const totalRounds = Math.ceil(totalWords / wordsPerRound);
  
  const getWordsForRound = (roundIndex: number) => {
    const startWord = roundIndex * wordsPerRound + 1;
    const endWord = Math.min((roundIndex + 1) * wordsPerRound, totalWords);
    return { start: startWord, end: endWord, count: endWord - startWord + 1 };
  };

  return (
    <div className="flex flex-col h-full p-4">
      <div className="flex items-center gap-4 mb-6">
        <button onClick={onBack} className="text-muted-foreground">
          ← Geri
        </button>
        <h2 className="text-xl font-bold text-foreground">Tur Seç</h2>
      </div>

      <p className="text-muted-foreground mb-6">
        Her turda kelime öğreneceksiniz. {totalRounds} turu tamamladığınızda {totalWords} kelimeyi öğrenmiş olacaksınız!
      </p>

      <ScrollArea className="flex-1">
        <div className="grid grid-cols-2 gap-3 pb-4">
          {Array.from({ length: totalRounds }, (_, i) => {
            const isCompleted = completedRounds.includes(i);
            const isUnlocked = i === 0 || completedRounds.includes(i - 1) || isCompleted;
            const roundWords = getWordsForRound(i);

            return (
              <button
                key={i}
                onClick={() => isUnlocked && onSelectRound(i)}
                disabled={!isUnlocked}
                className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                  isCompleted
                    ? 'border-green-500 bg-green-500/10'
                    : isUnlocked
                    ? 'border-primary bg-card hover:bg-primary/10'
                    : 'border-muted bg-muted/50 cursor-not-allowed'
                }`}
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  isCompleted
                    ? 'bg-green-500'
                    : isUnlocked
                    ? 'bg-primary'
                    : 'bg-muted'
                }`}>
                  {isCompleted ? (
                    <Check className="w-6 h-6 text-white" />
                  ) : isUnlocked ? (
                    <Play className="w-6 h-6 text-primary-foreground" />
                  ) : (
                    <Lock className="w-6 h-6 text-muted-foreground" />
                  )}
                </div>
                <span className={`font-semibold ${
                  isUnlocked ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  Tur {i + 1}
                </span>
                <span className="text-xs text-muted-foreground">
                  Kelime {roundWords.start}-{roundWords.end} ({roundWords.count})
                </span>
              </button>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}
